package Model;

public class Bustime {
    public String Place,Name;
    public int No,Time;

    public Bustime(int no,String place, String name, int time) {
        No=no;
        Place = place;
        Name = name;
        Time = time;
    }

    public String getPlace() {
        return Place;
    }

    public void setPlace(String place) {
        Place = place;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getNo() {
        return No;
    }

    public void setNo(int no) {
        No = no;
    }

    public int getTime() {
        return Time;
    }

    public void setTime(int time) {
        Time = time;
    }

    public Bustime(){

    }
}

