package com.example.fastmove.DataBase;

import android.annotation.SuppressLint;
import android.database.sqlite.SQLiteException;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

import Model.Bustime;

public class DataBase extends SQLiteAssetHelper{

 private static final String DB_Name = "bustime.db";
 private  static final int DB_Ver = 1;


    public DataBase(Context context) {
        super(context, DB_Name, null, DB_Ver);
    }


    @SuppressLint("Range")
    public List<Bustime> getBustime(){
        SQLiteDatabase  db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlselect= {"Place","Name","Time"};
        String  tableName = "BusTime";
        qb.setTables(tableName);
        Cursor cursor = qb.query(db,sqlselect,null,null,null,null,null);
        List<Bustime> result = new ArrayList<>();
        if (cursor.moveToFirst()) {

            do {
                Bustime  bustime = new Bustime();
                bustime.setPlace(cursor.getString(cursor.getColumnIndex("Place")));
                bustime.setName(cursor.getString(cursor.getColumnIndex("Name")));
                bustime.setTime(cursor.getInt(cursor.getColumnIndex("Time")));

                result.add(bustime);
            }while (cursor.moveToNext());
        }
        return  result;
    }




    @SuppressLint("Range")
    public List<String>  getPlace(){
        SQLiteDatabase  db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlselect = {"Place"};
        String  tableName = "BusTime";
        qb.setTables(tableName);
        Cursor cursor = qb.query(db,sqlselect,null,null,null,null,null);
        List<String> result = new ArrayList<>();
        if (cursor.moveToFirst()) {

            do {
               result.add(cursor.getString(cursor.getColumnIndex("Place")));
            }while (cursor.moveToNext());
        }
        return  result;
    }

    @SuppressLint("Range")
    public List<Bustime>  getBustimebyPlace(String place){
        SQLiteDatabase  db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlselect = {"Place","Name","Time"};
        String  tableName = "BusTime";
        qb.setTables(tableName);
        Cursor cursor = qb.query(db,sqlselect,"Place LIKE ?",new String[]{"%"+place+"%"},null,null,null);
        List<Bustime> result = new ArrayList<>();
        if (cursor.moveToFirst()) {

            do {
                Bustime  bustime = new Bustime();
                bustime.setPlace(cursor.getString(cursor.getColumnIndex("Place")));
                bustime.setName(cursor.getString(cursor.getColumnIndex("Name")));
                bustime.setTime(cursor.getInt(cursor.getColumnIndex("Time")));

                result.add(bustime);
            }while (cursor.moveToNext());
        }
        return  result;
    }
}
