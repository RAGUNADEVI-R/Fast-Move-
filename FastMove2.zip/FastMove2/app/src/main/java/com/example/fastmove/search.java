package com.example.fastmove;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.fastmove.Adapter.SearchAdapter;
import com.example.fastmove.DataBase.DataBase;
import com.mancj.materialsearchbar.MaterialSearchBar;

import java.util.ArrayList;
import java.util.List;


public class search extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);


       Button salem , trichy , coimbatore , dindugul , erode , ooty , madurai , kumbakonam;
        salem = findViewById(R.id.salem);
        trichy = findViewById(R.id.button16);
        coimbatore = findViewById(R.id.button17);
        dindugul = findViewById(R.id.button18);
        erode = findViewById(R.id.button19);
        ooty = findViewById(R.id.button20);
        madurai = findViewById(R.id.button21);
        kumbakonam = findViewById(R.id.button23);

        salem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,salem.class);
                startActivity(intent);

            }
        });

        trichy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,trichy.class);
                startActivity(intent);
            }
        });

        coimbatore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,coimbatore.class);
                startActivity(intent);
            }
        });

        dindugul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,dindugul.class);
                startActivity(intent);
            }
        });

        erode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,erode.class);
                startActivity(intent);
            }
        });

        ooty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,ooty.class);
                startActivity(intent);
            }
        });

        madurai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,madurai.class);
                startActivity(intent);
            }
        });

        kumbakonam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(search.this,kumbakonam.class);
                startActivity(intent);
            }
        });






      /* RecyclerView recyclerView;
        RecyclerView.LayoutManager layoutManager;
        SearchAdapter searchAdapter;
        MaterialSearchBar materialSearchBar;
        List<String> suggestList = new ArrayList<>();
        DataBase dataBase = new DataBase(this);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_search);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        materialSearchBar = (MaterialSearchBar) findViewById(R.id.search_bar);
        materialSearchBar.setHint("Search");
        materialSearchBar.setCardViewElevation(10);
        loadSuggestList();
        materialSearchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {
                if(!enabled)
                {
                  searchAdapter = new SearchAdapter(getBaseContext(),dataBase.getBustime());
                  recyclerView.setAdapter(searchAdapter);
                }
            }
            @Override
            public void onSearchConfirmed(CharSequence text) {
              startSearch(text.toString());
            }

            @Override
            public void onButtonClicked(int buttonCode) {
            }
        });

        searchAdapter = new SearchAdapter(this,dataBase.getBustime());
        recyclerView.setAdapter(searchAdapter);
          }
    private void startSearch(String text) {
        searchAdapter = new SearchAdapter(this,dataBase.getBustimebyPlace(text));
        recyclerView.setAdapter(searchAdapter);
    }
    private void loadSuggestList() {
        suggestList = dataBase.getPlace();
        materialSearchBar.setLastSuggestions(suggestList);
    }*/
    }
}


