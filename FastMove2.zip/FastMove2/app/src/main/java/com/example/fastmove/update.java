package com.example.fastmove;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class update extends AppCompatActivity {
    EditText usern;
    EditText mail;
    TextView upload;
    Button btname;;
    ImageView image;
     Database database;


    private Uri uri;
    private Bitmap bitmapimage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        usern= findViewById(R.id.editTextTextPersonName11);
        mail = findViewById(R.id.editTextTextPersonName12);
        upload =findViewById(R.id.textView12);
        btname = findViewById(R.id.button7);
        image = findViewById(R.id.imageView3);

        ActivityResultLauncher<Intent>  activityResultLauncher = registerForActivityResult
                (new ActivityResultContracts.StartActivityForResult(),
                        new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                    if(result.getResultCode() == Activity.RESULT_OK){
                        Intent data = result.getData();
                        assert data != null;
                        uri = data.getData();
                        try {
                            bitmapimage = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                        }catch (IOException e){
                            Toast.makeText(update.this, "e.getMessage()", Toast.LENGTH_SHORT).show();
                        }
                        image.setImageBitmap(bitmapimage);
                    }
                    else {
                        Toast.makeText(update.this, "No image selected", Toast.LENGTH_SHORT).show();
                    }
                    }
                });
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    activityResultLauncher.launch(intent);
                }
                catch (Exception e){
                    Toast.makeText(update.this, "e.getMessage()", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                storeImage();
            }
        });
    }
    private void  storeImage(){
        if(!usern.getText().toString().isEmpty() &&
                !mail.getText().toString().isEmpty() &&
        image.getDrawable()!= null && bitmapimage!= null){
            database.storeData(new  Mod(usern.getText().toString(),
                    mail.getText().toString(),bitmapimage));
            Intent intent = new Intent(update.this,profile.class);
            startActivity(intent);
        }else{
            Toast.makeText(this, "Fields are required", Toast.LENGTH_SHORT).show();
        }
    }
}