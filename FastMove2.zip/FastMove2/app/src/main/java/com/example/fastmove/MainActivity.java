package com.example.fastmove;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText username = findViewById(R.id.editTextTextPersonName2);
        EditText password = findViewById(R.id.editTextTextPersonName6);
        EditText  retype = findViewById(R.id.editTextTextPersonName3);
        TextView textView =  findViewById(R.id.textView);
        TextView textView4 = findViewById(R.id.textView4);
        Button button  = findViewById(R.id.button);
        DB = new DBHelper(this);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            String user= username.getText().toString();
            String pass = password.getText().toString();
            String repass =retype.getText().toString();

            if(user.equals("")||pass.equals("")||repass.equals(""))
                Toast.makeText(MainActivity.this,"Please enter all the fields",Toast.LENGTH_SHORT).show();
            else {
                if (pass.equals(repass)){
                    Boolean checkuser = DB.checkusername(user);
                    if (checkuser==false){
                        Boolean insert = DB.insertData(user, pass);
                        if (insert==true){
                            Toast.makeText(MainActivity.this,"Registered successfully",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent( getApplicationContext(),MainActivity3.class );
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(MainActivity.this,"Registration  failed",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(MainActivity.this,"User already exists! please login",Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(MainActivity.this,"Password not matched",Toast.LENGTH_SHORT).show();
                }
            }

            }
        });
        Button button2 =  findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( getApplicationContext(),MainActivity2.class );
                startActivity(intent);

            }
        });
             }
        }


