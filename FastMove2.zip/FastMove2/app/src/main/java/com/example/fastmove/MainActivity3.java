package com.example.fastmove;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        TextView name =findViewById(R.id.textView8);
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if(acct!=null){
            String personName = acct.getDisplayName();
            String personEmail = acct.getEmail();
            name.setText(personName);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater =getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.profile:
                Toast.makeText(MainActivity3.this,"Profile",Toast.LENGTH_LONG).show();
                Intent intentp = new Intent(MainActivity3.this,profile.class);
                startActivity(intentp);
                return true;
            case R.id.search:
                Toast.makeText(MainActivity3.this,"Search",Toast.LENGTH_LONG).show();
                Intent intent = new Intent( MainActivity3.this,search.class );
                startActivity(intent);
                finish();
                return true;
            case R.id.map:
                Toast.makeText(MainActivity3.this,"Map",Toast.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent1 = new Intent(MainActivity3.this,MapsActivity.class);
                        startActivity(intent1);
                        finish();
                    }
                },2500);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
