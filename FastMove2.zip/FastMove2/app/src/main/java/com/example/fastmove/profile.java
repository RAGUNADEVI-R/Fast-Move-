package com.example.fastmove;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.function.BiConsumer;

public class profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView name = findViewById(R.id.textView6);
        TextView mail = findViewById(R.id.textView7);
        ImageView image = findViewById(R.id.imageView3);
        Button edit = findViewById(R.id.button5);

        Database database = new Database(this);
        Cursor cursor = database.getUser();

        if (cursor.getCount()==0){
            Toast.makeText(this, "No details found", Toast.LENGTH_SHORT).show();
        }else {
            while (cursor.moveToNext()){
                name.setText(""+cursor.getString(0));
                mail.setText(""+cursor.getString(1));
                byte[] imageByte =  cursor.getBlob(2);

                Bitmap bitmap = BitmapFactory.decodeByteArray(imageByte,0,imageByte.length);
                image.setImageBitmap(bitmap);
            }
        }
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(profile.this,update.class);
                startActivity(intent);
            }
        });
    }
}