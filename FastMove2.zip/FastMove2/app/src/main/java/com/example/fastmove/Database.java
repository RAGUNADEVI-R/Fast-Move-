package com.example.fastmove;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;

public class Database extends SQLiteOpenHelper {

    Context context;
    public static  final String DBNAME ="login.db";
    private static String DBName = " profile.db";
    private static  int DBVersion= 1;
    private ByteArrayOutputStream byteArrayOutputStream;
    private  byte[]  byteimage;
    public  static String createTableQuery = "Create Table ProfileUser(name TEXT"
            + " ,email TEXT"
            + ", image BLOB)";

    public Database(@Nullable Context context) {
        super(context, DBName, null, DBVersion);
        this.context  = context;
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
    database.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public  void storeData(Mod Mod){
        SQLiteDatabase database = this.getWritableDatabase();
        Bitmap bitmapimage = Mod.getImage();

        byteArrayOutputStream = new ByteArrayOutputStream();
        bitmapimage.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
        byteimage =  byteArrayOutputStream.toByteArray();

        ContentValues contentValues = new ContentValues();
        contentValues.put("name",Mod.getName());
        contentValues.put("email",Mod.getEmail());

        long checkquery =  database.insert("ProfileUser",null,contentValues);
        if(checkquery!=-1){
            Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show();
            database.close();
        }else {
            Toast.makeText(context, "Something went wrong", Toast.LENGTH_SHORT).show();
        }
    }
    public Cursor  getUser(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("Select * from ProfileUser",null);
        return  cursor;
    }
}

