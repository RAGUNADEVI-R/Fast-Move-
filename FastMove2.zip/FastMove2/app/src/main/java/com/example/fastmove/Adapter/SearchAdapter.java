package com.example.fastmove.Adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fastmove.R;

import java.util.List;

import Model.Bustime;

class SearchviewHolder extends RecyclerView.ViewHolder{

    public TextView  place, name , time;
    public SearchviewHolder( View itemView) {
        super(itemView);
        place = (TextView) itemView.findViewById(R.id.place);
        name = (TextView) itemView.findViewById(R.id.name);
        time = (TextView) itemView.findViewById(R.id.time);
    }
}

public class SearchAdapter extends  RecyclerView.Adapter<SearchviewHolder> {
     private Context context;
     private final List<Bustime> bustime;


    public SearchAdapter(Context context, List<Bustime> bustime) {
        this.context = context;
        this.bustime = bustime;
    }

    @Override
    public SearchviewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View  itemView = inflater.inflate(R.layout.layout,parent,false);
        return new SearchviewHolder(itemView);
    }

    @Override
    public void onBindViewHolder( SearchviewHolder holder, int position) {
        holder.place.setText(bustime.get(position).getPlace());
        holder.name.setText(bustime.get(position).getName());
        holder.time.setText(bustime.get(position).getTime());
    }

    @Override
    public int getItemCount() {
        return bustime.size();
    }
}
